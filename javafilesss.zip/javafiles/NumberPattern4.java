import java.util.Scanner;
class NumberPattern4
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int num=1;

		int rows=sc.nextInt();
        int columns=sc.nextInt();
		for(int i=1;i<=rows;i++){
			//char ch='a';
          for(int j=1;j<=columns;j++){
		System.out.print(num++ +" ");
		
		}
		
		System.out.println();
		}
	}
}
